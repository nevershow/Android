package ml.huangjw.memory;

/**
 * Created by Kris on 16/10/9.
 */

// 备忘类
public class Memo {
  private String uuid;
  private String topic;
  private boolean isFinished;
  private String ddl;

  public Memo(String uuid, String topic, boolean isFinished, String ddl) {
    this.uuid = uuid;
    this.topic = topic;
    this.isFinished = isFinished;
    this.ddl = ddl;
  }

  public void setTopic(String topic) {
    this.topic = topic;
  }

  public void setDDL(String ddl) {
    this.ddl = ddl;
  }

  public boolean isFinished() {
    return isFinished;
  }

  public void setFinished(boolean finished) {
    isFinished = finished;
  }

  public void setUUID(String uuid) {
    this.uuid = uuid;
  }

  public String getUUID() {
    return uuid;
  }

  public String getDDL() {
    return ddl;
  }

  public String getTopic() {
    return topic;
  }
}
