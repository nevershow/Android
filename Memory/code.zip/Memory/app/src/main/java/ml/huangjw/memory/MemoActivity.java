package ml.huangjw.memory;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by Kris on 2016/12/15.
 */

public class MemoActivity extends AppCompatActivity {

  public static ArrayList<Memo> list_notCompleted;
  public static ArrayList<Memo> list_completed;

  public static String kind;

  @Bind(android.R.id.tabhost)
  FragmentTabHost mTabHost;

  @DrawableRes
  private int mImages[] = {
      R.drawable.tab_uncompleted,
      R.drawable.tab_completed
  };

  private String mFragmentTags[] = {
      "notCompleted",
      "completed"
  };

  private String mFragmentTabs[] = {
      "未完成",
      "已完成"
  };

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_memo);

    Intent intent = getIntent();
    Bundle bundle = intent.getExtras();
    kind = bundle.getString("taskName");

    initialTabHost();
    initialActionBar();
  }

  void initialTabHost() {
    ButterKnife.bind(this);

    mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);
    mTabHost.getTabWidget().setDividerDrawable(null);

    for (int i = 0; i < mImages.length; i++) {
      // Tab按钮添加文字和图片
      TabHost.TabSpec tabSpec = mTabHost.newTabSpec(mFragmentTags[i]).setIndicator(getView(i));
      // 添加Fragment
      mTabHost.addTab(tabSpec, MemoTab.class, null);
    }
  }

  // 获得图片资源
  private View getView(int index) {
    @SuppressLint("InflateParams")
    View view = getLayoutInflater().inflate(R.layout.memo_tab, null);

    ImageView imageView = (ImageView) view.findViewById(R.id.tab_iv_image);
    TextView textView = (TextView) view.findViewById(R.id.tab_tv_name);
    LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.tab_layout);

    textView.setText(mFragmentTabs[index]);
    imageView.setImageResource(mImages[index]);
    return view;
  }

  private void initialActionBar() {
    Bundle bundle = getIntent().getExtras();
    String taskName = bundle.getString("taskName");

    ActionBar actionBar = getSupportActionBar();
    actionBar.setTitle(taskName);
    actionBar.setDisplayHomeAsUpEnabled(true);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case android.R.id.home:
        this.finish();
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }
  }
}
