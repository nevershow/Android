package ml.huangjw.memory;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

/**
 * Created by Kris on 2016/12/1.
 */

public class CheckPermissionActivity extends AppCompatActivity {

  private Handler mHandler;
  private String[] permissions;

  private static final int REQUEST_CODE = 1;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // 动态检查Activity所需要的权限
    verifyPermissions(this);
  }

  private void verifyPermissions(Activity activity) {
    permissions = new String[]{
        Manifest.permission.INTERNET,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_WIFI_STATE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE);
  }

  @Override
  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);

    boolean flag = true;
    for (int i = 0; i < grantResults.length; i++) {
      if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
        flag = false;
        Toast.makeText(CheckPermissionActivity.this,
            "App will finish in 3 secs...", Toast.LENGTH_SHORT).show();

        mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
          @Override
          public void run() {
            finish();
          }
        }, 3000);
      }
    }

    if (flag) {
      Intent intent = new Intent();
      intent.setClass(CheckPermissionActivity.this, MainActivity.class);
      startActivity(intent);

      finish();
    }
  }
}
