package ml.huangjw.memory;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.jsoup.Jsoup;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

public class ModifyItemActivity extends AppCompatActivity {

  private static final String SERVER = "http://123.207.233.226:23333";
  private boolean first = true;
  private final int SPEED_SHRESHOLD = 4000;//这个值越大需要越大的力气来摇晃手机
  private long lastShakeTime = System.currentTimeMillis(), lastUpdateTime = 0;
  private float lastX, lastY, lastZ;

  private String placeDescription, placeUid;
  private double longitude, latitude;

  private MyDB mydb;

  private TextInputLayout ti_topic, ti_detail;
  private LinearLayout ll_place;
  private TextView tv_place;
  private Spinner sp_kind;
  private Button btn_date, btn_time;
  private Switch sw_remindTime, sw_remindPlace;
  private Calendar calendar;

  private Uri uri;
  private String type;
  private String uuid;
  private int pos;

  private List list_kind;
  private SensorManager mSensorManager;
  private SensorEventListener mSensorEventListener;
  private Sensor mAccelerometerSensor;
  private Vibrator vibrator;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_modify_item);

    Intent intent = getIntent();
    uri = intent.getData(); //获得Scheme名称

    // 判断是否是导入备忘
    if (uri != null && uri.getScheme().equals("memory")) {
      type = "add";
    } else {
      type = intent.getStringExtra("type");
    }

    initial();

    if (type.equals("edit")) {
      uuid = intent.getStringExtra("uuid");
      pos = intent.getIntExtra("pos", 0);
      setInfo();

      if (intent.hasExtra("cancel")) {
        Cursor cursor = mydb.getTask(uuid);
        cursor.moveToNext();

        long createTime = cursor.getLong(11);
        int code = (int) (createTime / 1000) - 1;

        cancelPlaceBroadcast(code);
      }
    }

    // 导入备忘
    if (uri != null && uri.getScheme().equals("memory")) {
      importTask();
    }
  }

  // 导入备忘, 为各控件赋值
  private void importTask() {
    uri = Uri.parse(uri.toString().replace("amp;", ""));
    uuid = uri.getQueryParameter("uuid");
    if (mydb.getTask(uuid).getCount() != 0) {
      type = "edit";
    }
    String topic = uri.getQueryParameter("topic");
    long ddl = Long.parseLong(uri.getQueryParameter("ddl"));
    String detail = uri.getQueryParameter("detail");
    boolean isTimeRemind = Boolean.valueOf(uri.getQueryParameter("isTimeRemind"));
    boolean isPlaceRemind = Boolean.valueOf(uri.getQueryParameter("isPlaceRemind"));
    placeUid = uri.getQueryParameter("placeUid");
    placeDescription = uri.getQueryParameter("placeDescription");
    longitude = Double.parseDouble(uri.getQueryParameter("longitude"));
    latitude = Double.parseDouble(uri.getQueryParameter("latitude"));
    String[] arr = timestamp2str(ddl).split(" ");

    ti_topic.getEditText().setText(topic);
    btn_date.setText(arr[0]);
    btn_time.setText(arr[1]);
    sw_remindTime.setChecked(isTimeRemind);
    sw_remindPlace.setChecked(isPlaceRemind);
    tv_place.setText(placeDescription);
    ti_detail.getEditText().setText(detail);
  }

  // 初始化控件, 监听器, 传感器
  private void initial() {
    ti_topic = (TextInputLayout) findViewById(R.id.ti_topic);
    ti_detail = (TextInputLayout) findViewById(R.id.ti_detail);
    ll_place = (LinearLayout) findViewById(R.id.ll_place);
    tv_place = (TextView) findViewById(R.id.tv_place);
    sp_kind = (Spinner) findViewById(R.id.sp_kind);
    btn_date = (Button) findViewById(R.id.btn_date);
    btn_time = (Button) findViewById(R.id.btn_time);
    sw_remindTime = (Switch) findViewById(R.id.sw_remindTime);
    sw_remindPlace = (Switch) findViewById(R.id.sw_remindPlace);


    calendar = Calendar.getInstance();
    mydb = MainActivity.myDB;
    vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
    placeDescription = "";
    placeUid = "";

    String[] arr = timestamp2str(System.currentTimeMillis()).split(" ");
    btn_date.setText(arr[0]);
    btn_time.setText(arr[1]);

    initialSpinner();
    initialActionBar();
    initSensor();
    addListeners();
  }

  // 初始化传感器, 摇一摇时分享
  private void initSensor() {
    mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
    mAccelerometerSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    mSensorEventListener = new SensorEventListener() {
      float[] accValues = null;

      @Override
      public void onSensorChanged(SensorEvent event) {
        switch (event.sensor.getType()) {
        // 加速度传感器变化, 计算速度,判断是否摇一摇
        case Sensor.TYPE_ACCELEROMETER:
          accValues = event.values.clone();
          if (System.currentTimeMillis() - lastUpdateTime > 50) {
            lastUpdateTime = System.currentTimeMillis();
            float deltaX = accValues[0] - lastX;
            float deltaY = accValues[1] - lastY;
            float deltaZ = accValues[2] - lastZ;
            lastX = accValues[0];
            lastY = accValues[1];
            lastZ = accValues[2];
            double speed = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ) * 200;

            // 速度超过阈值,前后两次间隔大于2秒
            if (speed >= SPEED_SHRESHOLD && lastUpdateTime - lastShakeTime > 2000 && !first && type.equals("edit")) {
              lastShakeTime = lastUpdateTime;
              vibrator.vibrate(500);
              Intent sendIntent = new Intent(Intent.ACTION_SEND);
              sendIntent.setType("text/plain");
              sendIntent.putExtra(Intent.EXTRA_TEXT, "难忘分享，一键导入\nhttp://123.207.233.226:23333/share?uuid=" + uuid);
              sendIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
              startActivity(Intent.createChooser(sendIntent, "难忘分享"));
              post2server();
            }
            first = false;
          }
          break;
        }
      }

      @Override
      public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };
  }

  // 分享时将备忘post到服务器, 以便他人导入
  private void post2server() {
    new Thread(new Runnable() {
      @Override
      public void run() {
        try {
          Map<String, String> json = new HashMap<String, String>();
          json.put("uuid", uuid);
          json.put("topic", ti_topic.getEditText().getText().toString());
          json.put("ddl", "" + str2timestamp(btn_date.getText().toString(), btn_time.getText().toString()));
          json.put("detail", ti_detail.getEditText().getText().toString());
          json.put("isTimeRemind", "" + sw_remindTime.isChecked());
          json.put("isPlaceRemind", "" + sw_remindPlace.isChecked());
          json.put("placeUid", placeUid);
          json.put("placeDescription", placeDescription);
          json.put("longitude", "" + longitude);
          json.put("latitude", "" + latitude);
          Jsoup.connect(SERVER + "/share").data(json).post();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }).start();
  }

  // 备忘详情页面, 设置各控件的值
  private void setInfo() {
    Cursor cursor = mydb.getTask(uuid);
    cursor.moveToNext();
    ti_topic.getEditText().setText(cursor.getString(2));
    sp_kind.setSelection(list_kind.indexOf(cursor.getString(1)));

    String[] arr = timestamp2str(cursor.getLong(3)).split(" ");
    btn_date.setText(arr[0]);
    btn_time.setText(arr[1]);

    ti_detail.getEditText().setText(cursor.getString(4));

    sw_remindTime.setChecked(Boolean.valueOf(cursor.getString(5)));
    sw_remindPlace.setChecked(Boolean.valueOf(cursor.getString(8)));

    placeUid = cursor.getString(9);
    placeDescription = cursor.getString(10);
    tv_place.setText(placeDescription);

    longitude = cursor.getDouble(13);
    latitude = cursor.getDouble(14);
  }

  // 保存备忘
  private void save() {
    String topic = ti_topic.getEditText().getText().toString().trim();
    if (topic.isEmpty()) {
      Toast.makeText(this, "事件名称不能为空", Toast.LENGTH_SHORT).show();
      return;
    }

    String kind = (String) sp_kind.getSelectedItem();
    long timestamp = str2timestamp(btn_date.getText().toString(),
                                   btn_time.getText().toString());
    boolean isRemindTime = sw_remindTime.isChecked();
    boolean isRemindPlace = sw_remindPlace.isChecked();
    String detail = ti_detail.getEditText().getText().toString();

    if (timestamp <= System.currentTimeMillis()) {
      Toast.makeText(this, "DDL必须在当前时间之后", Toast.LENGTH_SHORT).show();
      return;
    }

    if (isRemindPlace && placeUid.isEmpty()) {
      Toast.makeText(this, "请选择一个地点", Toast.LENGTH_SHORT).show();
      return;
    }

    // 添加备忘
    if (type.equals("add")) {
      String uuid = mydb.insertTask(kind, topic, timestamp, detail, isRemindTime,
                                    isRemindPlace, placeUid, placeDescription, longitude, latitude);

      setReminder(true, uuid);

      Cursor cursor = mydb.getTask(uuid);
      cursor.moveToNext();
      long createTime = cursor.getLong(11);
      int code = (int) (createTime / 1000) - 1;

      if (isRemindPlace) {
        openLocationBroadcast(uuid, code, longitude, latitude);
      }
    }
    // 更新备忘
    else {
      setReminder(false, uuid);
      mydb.updateTask(uuid, kind, topic, timestamp, detail, isRemindTime,
                      isRemindPlace, placeUid, placeDescription, longitude, latitude);
      Intent intent = new Intent();

      intent.putExtra("pos", pos);
      intent.putExtra("topic", topic);
      intent.putExtra("ddl", timestamp2str(timestamp));

      setResult(RESULT_OK, intent);
      setReminder(true, uuid);

      Cursor cursor = mydb.getTask(uuid);
      cursor.moveToNext();
      long createTime = cursor.getLong(11);
      int code = (int) (createTime / 1000) - 1;

      if (isRemindPlace) {
        cancelPlaceBroadcast(code);
        openLocationBroadcast(uuid, code, longitude, latitude);
      }
    }

    this.finish();
  }

  // 初始化状态栏
  private void initialActionBar() {
    ActionBar actionBar = getSupportActionBar();
    actionBar.setDisplayHomeAsUpEnabled(true);

    if (type.equals("edit")) {
      actionBar.setTitle("编辑");
    } else {
      actionBar.setTitle("添加");
    }
  }

  // 初始化下拉列表
  private void initialSpinner() {
    sp_kind = (Spinner) findViewById(R.id.sp_kind);

    if (mydb == null)
      mydb = new MyDB(this, "Memory", null, 1);
    list_kind = mydb.getKinds();

    ArrayAdapter arr_adapter = new ArrayAdapter<String>(this,
        android.R.layout.simple_spinner_item, list_kind);

    arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

    sp_kind.setAdapter(arr_adapter);
  }

  // 增加监听器
  private void addListeners() {
    // 是否选择地点提醒
    sw_remindPlace.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
      @Override
      public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
        if (isChecked) {
          ll_place.setVisibility(View.VISIBLE);
        } else {
          ll_place.setVisibility(View.GONE);
        }
      }
    });

    // 选择日期
    btn_date.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {

        new DatePickerDialog(ModifyItemActivity.this,
        new DatePickerDialog.OnDateSetListener() {
          @Override
          public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            btn_date.setText(new StringBuilder()
                             .append(year)
                             .append("-")
                             .append((month + 1) < 10 ? "0" + (month + 1) : (month + 1))
                             .append("-")
                             .append((dayOfMonth < 10) ? "0" + dayOfMonth : dayOfMonth));
          }
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
                            ).show();
      }
    });

    // 选择时间
    btn_time.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        new TimePickerDialog(ModifyItemActivity.this,
        new TimePickerDialog.OnTimeSetListener() {
          @Override
          public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
            btn_time.setText(new StringBuilder()
                             .append(hourOfDay < 10 ? "0" + hourOfDay : hourOfDay)
                             .append(":")
                             .append(minute < 10 ? "0" + minute : minute));
          }
        },
        calendar.get(Calendar.HOUR_OF_DAY),
        calendar.get(Calendar.MINUTE), true
                            ).show();
      }
    });

    // 标记地点
    tv_place.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Intent intent = new Intent();
        intent.setClass(ModifyItemActivity.this, MapActivity.class);
        startActivityForResult(intent, 0);
      }
    });
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_save, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
    case android.R.id.home:
      this.finish();
      return true;
    case R.id.action_save:
      save();
      return true;
    default:
      return super.onOptionsItemSelected(item);
    }
  }

  // 开启位置提醒
  private void openLocationBroadcast(String uuid, int id, double longitude, double latitude) {
    Intent intent = new Intent(getBaseContext(), LocationReceiver.class);
    intent.setAction("ml.huangjw.memory.ALARM_SERVICE");

    Calendar calendar = Calendar.getInstance();

    intent.putExtra("longitude", longitude);
    intent.putExtra("latitude", latitude);
    intent.putExtra("uuid", uuid);
    intent.putExtra("description", placeDescription);
    intent.putExtra("id", id);

    PendingIntent operation = PendingIntent
                              .getBroadcast(getBaseContext(), id, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);

    am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), operation);
  }

  // 取消位置提醒
  private void cancelPlaceBroadcast(int id) {
    Intent intentService = new Intent(getBaseContext(), LocationService.class);
    Intent intentBroadCast = new Intent(getBaseContext(), LocationReceiver.class);

    intentService.setAction("ml.huangjw.memory.LOCATION_SERVICE");
    intentBroadCast.setAction("ml.huangjw.memory.ALARM_SERVICE");

    PendingIntent operation = PendingIntent
                              .getBroadcast(ModifyItemActivity.this, id, intentBroadCast, PendingIntent.FLAG_UPDATE_CURRENT);
    stopService(intentService);

    AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
    am.cancel(operation);
  }

  // 设置时间提醒的开启和关闭
  private void setReminder(boolean isSet, String uuid) {
    Cursor cursor = mydb.getTask(uuid);
    cursor.moveToNext();
    String topic = cursor.getString(2);
    boolean isTimeRemind = Boolean.valueOf(cursor.getString(5));
    long thirty = cursor.getLong(6);
    long seventy = cursor.getLong(7);
    long ddl = cursor.getLong(3);
    AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);

    int ddl_code = (int) (ddl / 1000);
    int thirty_code = (int) (thirty / 1000);
    int seventy_code = (int) (seventy / 1000);

    // 所选时间的提醒
    PendingIntent ddl_operation = PendingIntent.getBroadcast(this,
                                  ddl_code,
                                  new Intent(this, AlarmReceiver.class).putExtra("id", ddl_code).putExtra("uuid", uuid).putExtra("process", 2).putExtra("topic", topic),
                                  PendingIntent.FLAG_UPDATE_CURRENT);

    // 过了30%时间的提醒
    PendingIntent thirty_operation = PendingIntent.getBroadcast(this,
                                     thirty_code,
                                     new Intent(this, AlarmReceiver.class).putExtra("id", thirty_code).putExtra("uuid", uuid).putExtra("process", 0).putExtra("topic", topic),
                                     PendingIntent.FLAG_UPDATE_CURRENT);

    // 过了70%时间的提醒
    PendingIntent seventy_operation = PendingIntent.getBroadcast(this,
                                      seventy_code,
                                      new Intent(this, AlarmReceiver.class).putExtra("id", seventy_code).putExtra("uuid", uuid).putExtra("process", 1).putExtra("topic", topic),
                                      PendingIntent.FLAG_UPDATE_CURRENT);
    calendar.setTimeZone(TimeZone.getTimeZone("GMT+8"));

    // 根据是否分时段开启对应的提醒
    if (isSet) {
      calendar.setTimeInMillis(ddl);
      // 设置AlarmManager在对应的时间启动Activity
      am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), ddl_operation);

      if (isTimeRemind) {
        calendar.setTimeInMillis(thirty);
        if (calendar.getTimeInMillis() > System.currentTimeMillis()) {
          am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), thirty_operation);
        }
        calendar.setTimeInMillis(seventy);
        if (calendar.getTimeInMillis() > System.currentTimeMillis()) {
          am.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), seventy_operation);
        }
      }
    }

    // 根据是否分时段取消对应的提醒
    else {
      am.cancel(ddl_operation);
      if (isTimeRemind) {
        am.cancel(thirty_operation);
        am.cancel(seventy_operation);
      }
    }
  }

  // 选择标记地点后返回位置信息
  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == 0 && resultCode == RESULT_OK) {
      placeDescription = data.getExtras().getString("placeDescription");
      placeUid = data.getExtras().getString("placeUid");
      longitude = data.getExtras().getDouble("longitude");
      latitude = data.getExtras().getDouble("latitude");

      tv_place.setText(placeDescription);
    }
  }

  // 日期时间转时间戳
  long str2timestamp(String date, String time) {
    try {
      calendar.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(date + " " + time));
      return calendar.getTimeInMillis();
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return -1;
  }

  // 时间戳转日期时间
  String timestamp2str(long timestamp) {
    Date date = new Date(timestamp);
    return (new SimpleDateFormat("yyyy-MM-dd HH:mm").format(timestamp));
  }

  @Override
  protected void onResume() {
    super.onResume();
    mSensorManager.registerListener(mSensorEventListener, mAccelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
  }

  @Override
  protected void onPause() {
    super.onPause();
    mSensorManager.unregisterListener(mSensorEventListener);
  }

  // 当应用开启时, 导入备忘触发该函数
  @Override
  protected void onRestart() {
    super.onRestart();
    uri = getIntent().getData(); //获得Scheme名称
    if (uri != null && uri.getScheme().equals("memory")) {
      type = "add";
      importTask();
    }
  }
}
