package ml.huangjw.memory;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/**
 * Created by Huangjw on 2016/12/18.
 */

// 接收地点提醒并发送通知
public class NotificationReceiver extends BroadcastReceiver {

  @Override
  public void onReceive(Context context, Intent intent) {

    NotificationManager manager =
      (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);

    Notification.Builder builder = new Notification.Builder(context);

    builder.setContentTitle("地点提醒")
    .setContentText("您在" + intent.getStringExtra("address") + "附近")
    .setTicker("难忘提醒")
    .setAutoCancel(true)
    .setSmallIcon(R.mipmap.launcher)
    .setDefaults(Notification.DEFAULT_ALL);

    Intent mIntent = new Intent(context, MainActivity.class);

    Bundle bundle = new Bundle();
    bundle.putString("uuid", intent.getStringExtra("uuid"));
    bundle.putString("type", "map");

    mIntent.putExtras(bundle);

    PendingIntent mPendingIntent = PendingIntent.getActivity(context,
                                   intent.getIntExtra("id", 0), mIntent, 0);
    builder.setContentIntent(mPendingIntent);

    Notification notify = builder.build();

    manager.notify(intent.getIntExtra("id", 0), notify);
  }
}
