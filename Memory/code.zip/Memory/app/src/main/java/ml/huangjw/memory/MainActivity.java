package ml.huangjw.memory;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

  public static MyDB myDB;
  public final String DBNAME = "Memory";

  private ListView lv_task;
  private List<Map<String, Object>> list_task;
  private SimpleAdapter sa_task;

  private ImageView iv_avatar;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    initial();
  }

  // 设置头像
  private void setAvatar() {
    try (FileInputStream fis = openFileInput("avatar.png")) {
      byte[] contents = new byte[fis.available()];
      fis.read(contents);
      fis.close();
      iv_avatar.setImageBitmap(BitmapFactory.decodeByteArray(contents, 0, contents.length));
    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  @Override
  protected void onResume() {
    super.onResume();
    setAvatar();

    // 初始化清单
    ArrayList<String> kinds = myDB.getKinds();
    list_task.clear();

    for (int i = 0; i < kinds.size(); i++) {
      Map<String, Object> temp = new LinkedHashMap<>();
      temp.put("icon", R.mipmap.menu);
      temp.put("name", kinds.get(i));

      int notCompleted = myDB.getCount(kinds.get(i), false);
      int completed = myDB.getCount(kinds.get(i), true);

      temp.put("notCompleted", notCompleted);
      temp.put("number", notCompleted + completed);
      list_task.add(temp);
    }
    // 最后一项是新建清单
    Map<String, Object> newTask = new LinkedHashMap<>();
    newTask.put("icon", R.mipmap.add);
    newTask.put("name", "新建清单");
    newTask.put("notCompleted", "");
    newTask.put("number", "");
    list_task.add(newTask);

    sa_task.notifyDataSetChanged();
    // 假如Intent里面有uuid，那么将跳转至备忘详情页
    Intent intent = getIntent();
    if (intent.hasExtra("uuid")) {
      String uuid = intent.getStringExtra("uuid");
      intent.removeExtra("uuid");
      Intent mIntent = new Intent(this, ModifyItemActivity.class);
      mIntent.putExtra("uuid", uuid);
      mIntent.putExtra("type", "edit");

      if (intent.hasExtra("type")) {
        mIntent.putExtra("cancel", "map");
        intent.removeExtra("type");
      }

      startActivity(mIntent);
    }
  }

  private void initial() {
    myDB = new MyDB(MainActivity.this, DBNAME, null, 1);

    initialToolbar();
    initialAvatar();

    // 添加备忘的按钮
    FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.add);
    fab.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Intent intent = new Intent(MainActivity.this,
            ModifyItemActivity.class);
        intent.putExtra("type", "add");
        startActivity(intent);
      }
    });

    initialListView();
  }

  private void initialAvatar() {
    iv_avatar = (ImageView) findViewById(R.id.iv_avatar);
    // 点击头像将跳转至设置头像的Activity
    iv_avatar.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Intent intent = new Intent(getApplicationContext(),
            AvatarActivity.class);
        startActivity(intent);
      }
    });

    setAvatar();
  }

  private void initialToolbar() {
    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
    toolbar.setTitle("");
    setSupportActionBar(toolbar);
  }

  private void initialListView() {
    lv_task = (ListView) findViewById(R.id.lv_task);
    list_task = new ArrayList<>();

    sa_task = new SimpleAdapter(this, list_task, R.layout.task_item,
        new String[]{"icon", "name", "number", "notCompleted"},
        new int[]{R.id.iv_icon, R.id.tv_name, R.id.tv_number, R.id.tv_notCompleted});

    lv_task.setAdapter(sa_task);

    // 点击清单将跳转至清单详情页，如果是新建清单那么就新建清单
    lv_task.setOnItemClickListener(new AdapterView.OnItemClickListener() {

      @Override
      public void onItemClick(AdapterView<?> parent, View view,
                              final int position, long id) {
        TextView tv_name = (TextView) view.findViewById(R.id.tv_name);

        if (position != (sa_task.getCount() - 1)) {
          Intent intent = new Intent(MainActivity.this, MemoActivity.class);

          Bundle bundle = new Bundle();
          bundle.putString("taskName", tv_name.getText().toString());

          intent.putExtras(bundle);
          startActivity(intent);
        } else {
          LayoutInflater factory = LayoutInflater.from(MainActivity.this);
          View dialogView = factory.inflate(R.layout.dialog_add_task, null);
          final EditText et_addTask = (EditText) dialogView.findViewById(R.id.et_addTask);

          Dialog alertDialog = new AlertDialog.Builder(MainActivity.this).
              setTitle("新建清单").
              setView(dialogView).
              setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
              }).
              setPositiveButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  String name = et_addTask.getText().toString().trim();

                  if (!name.isEmpty()) {
                    if (myDB.insertKind(name)) {
                      Map<String, Object> temp = new LinkedHashMap<>();

                      temp.put("icon", R.mipmap.menu);
                      temp.put("name", name);
                      temp.put("number", 0);
                      temp.put("notCompleted", 0);

                      list_task.add(list_task.size() - 1, temp);

                      sa_task.notifyDataSetChanged();
                    } else {
                      Toast.makeText(MainActivity.this, "清单已存在",
                          Toast.LENGTH_SHORT).show();
                    }
                  } else {
                    Toast.makeText(MainActivity.this, "清单名字不能为空",
                        Toast.LENGTH_SHORT).show();
                  }
                }
              }).create();
          alertDialog.show();
        }
      }
    });

    // 长按将删除清单和该清单里面的所有备忘
    lv_task.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

      @Override
      public boolean onItemLongClick(AdapterView<?> parent, View view,
                                     final int position, long id) {

        if (position != (sa_task.getCount() - 1)) {
          final TextView name = (TextView) view.findViewById(R.id.tv_name);
          Dialog alertDialog = new AlertDialog.Builder(MainActivity.this).
              setTitle("删除清单").
              setMessage("确定删除清单: " + name.getText().toString() + "?").
              setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
              }).
              setPositiveButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  myDB.deleteTask(name.getText().toString(), "kind");
                  myDB.deleteKind(name.getText().toString());

                  list_task.remove(position);
                  sa_task.notifyDataSetChanged();
                }
              }).
              create();
          alertDialog.show();
        }
        return true;
      }
    });
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_main, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    int id = item.getItemId();

    switch (item.getItemId()) {
      case R.id.action_search:
        Intent intent = new Intent(MainActivity.this, SearchActivity.class);
        startActivity(intent);
        return true;
      default:
        break;
    }

    return super.onOptionsItemSelected(item);
  }

  @Override
  protected void onNewIntent(Intent intent) {
    setIntent(intent);
    super.onNewIntent(intent);
  }
}
