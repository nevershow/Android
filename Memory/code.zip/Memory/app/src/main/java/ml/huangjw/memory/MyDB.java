package ml.huangjw.memory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.UUID;

/**
 * Created by Huangjw on 2016/12/14.
 */


public class MyDB extends SQLiteOpenHelper {
  private static final String TABLENAME = "Task";
  private static final String TAG = "Memory";

  private SQLiteDatabase db;

  public MyDB(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
    super(context, name, factory, version);
    db = getWritableDatabase();
  }

  // 创建数据表在备忘分类增加默认清单一项
  @Override
  public void onCreate(SQLiteDatabase db) {
    String sql = "create table if not exists " + TABLENAME +
                 "( [uuid] Text NOT NULL PRIMARY KEY, \n" +
                 "  [kind] TEXT NOT NULL, \n" +
                 "  [topic] TEXT NOT NULL, \n" +
                 "  [ddl] long NOT NULL, \n" +
                 "  [detail] TEXT DEFAULT '', \n" +
                 "  [isTimeRemind] TEXT, \n" +
                 "  [thirty] long DEFAULT 0, \n" +
                 "  [seventy] long DEFAULT 0, \n" +
                 "  [isPlaceRemind] TEXT, \n" +
                 "  [placeUid] TEXT DEFAULT '', \n" +
                 "  [placeDescription] TEXT DEFAULT '', \n" +
                 "  [createTime] long, \n" +
                 "  [isFinished] TEXT DEFAULT 'false', \n" +
                 "  [longitude] double DEFAULT 0, \n" +
                 "  [latitude] double DEFAULT 0);";
    db.execSQL(sql);
    sql = "create table if not exists Kind ([kind] TEXT NOT NULL PRIMARY KEY);";
    db.execSQL(sql);
    sql = "insert into Kind values ('默认清单')";
    db.execSQL(sql);
  }

  // 新建备忘, 返回该备忘的uuid
  public String insertTask(String kind, String topic, long ddl, String detail, boolean isTimeRemind, boolean isPlaceRemind, String placeUid, String placeDescription, double longitude, double latitude) {
    ContentValues cv = new ContentValues();
    String uuid = UUID.randomUUID().toString();
    long createTime = System.currentTimeMillis();
    cv.put("uuid", uuid);
    cv.put("kind", kind);
    cv.put("topic", topic);
    cv.put("ddl", ddl);
    cv.put("detail", detail);
    cv.put("isTimeRemind", "" + isTimeRemind);
    cv.put("thirty", (ddl - createTime) * 3 / 10 + createTime);
    cv.put("seventy", (ddl - createTime) * 7 / 10 + createTime);
    cv.put("isPlaceRemind", "" + isPlaceRemind);
    cv.put("placeUid", placeUid);
    cv.put("placeDescription", placeDescription);
    cv.put("createTime", System.currentTimeMillis());
    cv.put("longitude", longitude);
    cv.put("latitude", latitude);
    return db.insert(TABLENAME, null, cv) == -1 ? "" : uuid;
  }

  // 新建清单
  public boolean insertKind(String kind) {
    ContentValues cv = new ContentValues();
    cv.put("kind", kind);
    return db.insert("Kind", null, cv) != -1;
  }

  // 根据uuid或者分类删除任务
  public void deleteTask(String selction, String type) {
    db.delete(TABLENAME, type + " = ?", new String[] {selction});
  }

  // 删除清单
  public void deleteKind(String kind) {
    db.delete("Kind", "kind = ?", new String[] {kind});
  }

  // 更新备忘
  public void updateTask(String uuid, String kind, String topic, long ddl, String detail,
                         boolean isTimeRemind, boolean isPlaceRemind, String placeUid,
                         String placeDescription, double longitude, double latitude) {
    long createTime = getCreateTime(uuid);
    ContentValues cv = new ContentValues();
    cv.put("kind", kind);
    cv.put("topic", topic);
    cv.put("ddl", ddl);
    cv.put("detail", detail);
    cv.put("isTimeRemind", isTimeRemind + "");
    cv.put("thirty", (ddl - createTime) * 3 / 10 + createTime);
    cv.put("seventy", (ddl - createTime) * 7 / 10 + createTime);
    cv.put("isPlaceRemind", isPlaceRemind + "");
    cv.put("placeUid", placeUid);
    cv.put("placeDescription", placeDescription);
    cv.put("longitude", longitude);
    cv.put("latitude", latitude);
    db.update(TABLENAME, cv, "uuid = ?", new String[] {uuid});
  }

  // 获取备忘创建时间
  private long getCreateTime(String uuid) {
    Cursor cursor = db.rawQuery("select createTime from " + TABLENAME + " where uuid = ?", new String[] {uuid});
    while (cursor.moveToNext()) {
      return cursor.getLong(0);
    }
    return -1L;
  }

  // 获取所有完成和未完成的备忘
  public Cursor getTasks(boolean isFinished) {
    Cursor cursor = db.rawQuery("select uuid, topic, ddl from " + TABLENAME + " where isFinished = ?", new String[] {String.valueOf(isFinished)});
    return cursor;
  }

  // 获取某一清单完成和未完成的备忘
  public Cursor getTasks(String kind, boolean isFinished) {
    Cursor cursor = db.rawQuery("select uuid, topic, ddl from " + TABLENAME + " where kind = ? and isFinished = ?", new String[] {kind, String.valueOf(isFinished)});
    return cursor;
  }

  // 获取特定某条备忘
  public Cursor getTask(String uuid) {
    return db.rawQuery("select * from " + TABLENAME + " where uuid = ?", new String[] {uuid});
  }

  // 更新备忘完成情况
  public void updateFinish(String uuid, boolean isfinished) {
    ContentValues cv = new ContentValues();
    cv.put("isFinished", isfinished + "");
    db.update(TABLENAME, cv, "uuid = ?", new String[] {uuid});
  }

  // 获取某一清单完成和未完成备忘的数量
  public int getCount(String kind, boolean finished) {
    Cursor cursor = db.rawQuery("select uuid from " + TABLENAME + " where kind = ? and isFinished = ?", new String[] {kind, String.valueOf(finished)});
    return cursor.getCount();
  }

  // 获取所有备忘
  public Cursor getAll() {
    return db.rawQuery("select uuid, topic, isFinished, ddl from " + TABLENAME + " order by isFinished asc, ddl asc", null);
  }

  // 获取所有清单类型
  public ArrayList<String> getKinds() {
    ArrayList<String> arr = new ArrayList<>();
    Cursor cursor = db.rawQuery("select * from Kind", null);
    while (cursor.moveToNext()) {
      arr.add(cursor.getString(0));
    }
    return arr;
  }

  @Override
  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
}
