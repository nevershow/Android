package ml.huangjw.memory;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import butterknife.Bind;
import butterknife.ButterKnife;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.ALARM_SERVICE;

/**
 * Created by Kris on 2016/12/15.
 */

public class MemoTab extends Fragment {
  @Bind(R.id.lv_memo)
  ListView lv_memo;

  private MemoListAdapter ma_memo;

  private String currentTab;
  private View mViewContent; // 缓存视图内容

  private MyDB myDB;

  @Override
  public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    myDB = MainActivity.myDB;
    // 读取完成和未完成的备忘，并根据Tag设置ListView的Adapter
    if (getTag().equals("completed")) {
      ma_memo = new MemoListAdapter(getContext(), MemoActivity.list_completed);
    } else {

      MemoActivity.list_completed = new ArrayList<Memo>();
      Cursor completedCursor = myDB.getTasks(MemoActivity.kind, true);

      while (completedCursor.moveToNext()) {
        Memo memo = new Memo(completedCursor.getString(0),
            completedCursor.getString(1), true,
            timestamp2str(completedCursor.getLong(2)));
        MemoActivity.list_completed.add(memo);
      }
      completedCursor.close();

      MemoActivity.list_notCompleted = new ArrayList<Memo>();
      Cursor notCompletedCursor = myDB.getTasks(MemoActivity.kind, false);

      while (notCompletedCursor.moveToNext()) {
        Memo memo = new Memo(notCompletedCursor.getString(0),
            notCompletedCursor.getString(1), false,
            timestamp2str(notCompletedCursor.getLong(2)));
        MemoActivity.list_notCompleted.add(memo);
      }
      notCompletedCursor.close();

      ma_memo = new MemoListAdapter(getContext(), MemoActivity.list_notCompleted);
    }
  }

  @Nullable
  @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    if (mViewContent == null) {
      mViewContent = inflater.inflate(R.layout.memo_list, container, false);
    }

    ViewGroup parent = (ViewGroup) mViewContent.getParent();
    if (parent != null) {
      parent.removeView(mViewContent);
    }

    ButterKnife.bind(this, mViewContent);

    return mViewContent;
  }

  @Override
  public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);

    String tag = getTag();

    if (tag.equals("notCompleted")) {
      currentTab = "notCompleted";
      lv_memo.setAdapter(ma_memo);
    } else {
      currentTab = "completed";
      lv_memo.setAdapter(ma_memo);
    }

    // 点击将跳转至备忘详情页
    lv_memo.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent intent = new Intent();
        intent.setClass(getContext(), ModifyItemActivity.class);
        intent.putExtra("type", "edit");
        Memo memo = (Memo) ma_memo.getItem(i);
        intent.putExtra("uuid", memo.getUUID());
        intent.putExtra("pos", i);
        startActivityForResult(intent, 0);
      }
    });

    // 长按删除并且取消提醒
    lv_memo.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
      @Override
      public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int i, long l) {
        final Memo memo = (Memo) ma_memo.getItem(i);
        Dialog alertDialog = new AlertDialog.Builder(getContext()).
            setTitle("删除事件").
            setMessage("确定删除事件: " + memo.getTopic() + "?").
            setNegativeButton("取消", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
              }
            }).
            setPositiveButton("确定", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
                cancelReminder(memo.getUUID());

                Cursor cursor = myDB.getTask(memo.getUUID());
                cursor.moveToNext();

                long createTime = cursor.getLong(11);
                int code = (int) (createTime / 1000) - 1;

                cancelPlaceBroadcast(code);
                myDB.deleteTask(memo.getUUID(), "uuid");
                if (currentTab.equals("completed")) {
                  MemoActivity.list_completed.remove(i);
                } else {
                  MemoActivity.list_notCompleted.remove(i);
                }
                ma_memo.notifyDataSetChanged();
              }
            }).
            create();
        alertDialog.show();
        return true;
      }
    });
  }

  private void cancelReminder(String uuid) {
    Cursor cursor = myDB.getTask(uuid);
    cursor.moveToNext();

    String topic = cursor.getString(2);

    boolean isTimeRemind = Boolean.valueOf(cursor.getString(5));
    long thirty = cursor.getLong(6);
    long seventy = cursor.getLong(7);
    long ddl = cursor.getLong(3);
    AlarmManager am = (AlarmManager) getContext().getSystemService(ALARM_SERVICE);

    int ddl_code = (int) (ddl / 1000);
    int thirty_code = (int) (thirty / 1000);
    int seventy_code = (int) (seventy / 1000);

    Calendar calendar = Calendar.getInstance();

    PendingIntent ddl_operation = PendingIntent.getBroadcast(getContext(),
        ddl_code,
        new Intent(getContext(), AlarmReceiver.class).putExtra("id", ddl_code).putExtra("uuid", uuid).putExtra("process", 2).putExtra("topic", topic),
        PendingIntent.FLAG_UPDATE_CURRENT);
    PendingIntent thirty_operation = PendingIntent.getBroadcast(getContext(),
        thirty_code,
        new Intent(getContext(), AlarmReceiver.class).putExtra("id", thirty_code).putExtra("uuid", uuid).putExtra("process", 0).putExtra("topic", topic),
        PendingIntent.FLAG_UPDATE_CURRENT);
    PendingIntent seventy_operation = PendingIntent.getBroadcast(getContext(),
        seventy_code,
        new Intent(getContext(), AlarmReceiver.class).putExtra("id", seventy_code).putExtra("uuid", uuid).putExtra("process", 1).putExtra("topic", topic),
        PendingIntent.FLAG_UPDATE_CURRENT);
    calendar.setTimeZone(TimeZone.getTimeZone("GMT+8"));

    am.cancel(ddl_operation);

    if (isTimeRemind) {
      am.cancel(thirty_operation);
      am.cancel(seventy_operation);
    }

    // Toast.makeText(getContext(), "闹钟取消完毕~", Toast.LENGTH_SHORT).show();
  }

  private void cancelPlaceBroadcast(int id) {
    Intent intentService = new Intent(getContext(), LocationService.class);
    Intent intentBroadCast = new Intent(getContext(), LocationReceiver.class);

    intentService.setAction("ml.huangjw.memory.LOCATION_SERVICE");
    intentBroadCast.setAction("ml.huangjw.memory.ALARM_SERVICE");

    PendingIntent operation = PendingIntent
        .getBroadcast(getContext(), id, intentBroadCast, PendingIntent.FLAG_UPDATE_CURRENT);
    getContext().stopService(intentService);

    AlarmManager am = (AlarmManager) getContext().getSystemService(ALARM_SERVICE);
    am.cancel(operation);
  }

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    if (requestCode == 0 && resultCode == RESULT_OK) {
      int pos = data.getIntExtra("pos", 0);
      String topic = data.getStringExtra("topic");
      String ddl = data.getStringExtra("ddl");

      Memo memo = (Memo) ma_memo.getItem(pos);
      memo.setDDL(ddl);
      memo.setTopic(topic);

      ma_memo.notifyDataSetChanged();
    }
  }

  @Override
  public void onDestroyView() {
    super.onDestroyView();
    ButterKnife.unbind(this);
  }

  String timestamp2str(long timestamp) {
    Date date = new Date(timestamp);
    return (new SimpleDateFormat("yyyy-MM-dd HH:mm").format(timestamp));
  }

  public class MemoListAdapter extends BaseAdapter {

    private List<Memo> memoList;
    private Context context;

    public MemoListAdapter(Context context, List<Memo> memoList) {
      this.memoList = memoList;
      this.context = context;
    }

    public List<Memo> getMemoList() {
      return memoList;
    }

    @Override
    public int getCount() {
      if (memoList == null) {
        return 0;
      }
      return memoList.size();
    }

    @Override
    public Object getItem(int position) {
      if (memoList == null) {
        return null;
      }
      return memoList.get(position);
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {
      View convertView;

      convertView = LayoutInflater.from(context).inflate(R.layout.memo_item, null);

      final CheckBox cb_isFinished = (CheckBox) convertView.findViewById(R.id.cb_isFinished);
      final TextView tv_topic = (TextView) convertView.findViewById(R.id.tv_topic);
      TextView tv_ddl = (TextView) convertView.findViewById(R.id.tv_ddl);

      final String topic = memoList.get(position).getTopic();
      String ddl = memoList.get(position).getDDL();
      boolean isFinished = memoList.get(position).isFinished();

      cb_isFinished.setTag(0);

      // 点击复选框将提醒是否完成或者未完成
      cb_isFinished.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView,
                                     final boolean isChecked) {
          if ((int) cb_isFinished.getTag() == 1) {
            cb_isFinished.setTag(0);
            return;
          }

          String title = "";
          if (isChecked && currentTab.equals("notCompleted")) {
            title = "是否完成\"" + topic + "\"";
          } else if (!isChecked && currentTab.equals("completed")) {
            title = "是否恢复\"" + topic + "\"";
          } else {
            return;
          }

          Dialog alertDialog = new AlertDialog.Builder(getContext()).
              setTitle(title).
              setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  cb_isFinished.setTag(1);
                  cb_isFinished.setChecked(!isChecked);
                }
              }).
              setPositiveButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  Memo memo = (Memo) getItem(position);
                  memo.setFinished(isChecked);

                  if (currentTab.equals("notCompleted")) {
                    MemoActivity.list_completed.add(0, memo);
                  } else {
                    MemoActivity.list_notCompleted.add(0, memo);
                  }
                  Cursor cursor = myDB.getTask(memo.getUUID());
                  cursor.moveToNext();

                  long createTime = cursor.getLong(11);
                  int code = (int) (createTime / 1000) - 1;

                  cancelPlaceBroadcast(code);
                  cancelReminder(memo.getUUID());
                  myDB.updateFinish(memo.getUUID(), isChecked);

                  memoList.remove(position);
                  notifyDataSetChanged();
                }
              }).
              create();
          alertDialog.show();
        }
      });

      tv_ddl.setText(ddl);
      cb_isFinished.setChecked(isFinished);
      tv_topic.setText(topic);

      return convertView;
    }
  }
}
