package ml.huangjw.memory;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by kx on 2016/12/14.
 */
public class SearchActivity extends AppCompatActivity {

  private ListView lv_search;
  private ArrayList<Memo> list_memo;
  private MemoListAdapter ma_memo;

  private MyDB myDB;

  private final Object mLock = new Object();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_search);

    initial();
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case android.R.id.home:
        this.finish();
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.menu_search, menu);

    MenuItem searchItem = menu.findItem(R.id.action_search);
    SearchView searchView = (SearchView) searchItem.getActionView();
    // 配置SearchView的属性

    ImageView searchButton = (ImageView) searchView.findViewById(R.id.search_button);
    searchButton.callOnClick();

    searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

      // 当点击搜索按钮时触发该方法
      @Override
      public boolean onQueryTextSubmit(String query) {
        return false;
      }

      // 当搜索内容改变时触发该方法
      @Override
      public boolean onQueryTextChange(String newText) {
        MemoListAdapter adapter = (MemoListAdapter) lv_search.getAdapter();
        if (adapter instanceof Filterable) {
          Filter filter = ((Filterable) adapter).getFilter();
          if (newText == null || newText.trim().isEmpty()) {
            filter.filter(null);
          } else {
            filter.filter(newText);
          }
        }
        return true;
      }
    });
    return super.onCreateOptionsMenu(menu);
  }

  private void initial() {
    initialActionbar();
    initialListView();

    myDB = MainActivity.myDB;
  }

  private void initialActionbar() {
    ActionBar actionBar = getSupportActionBar();

    actionBar.setDisplayHomeAsUpEnabled(true);
    actionBar.setTitle("");
  }

  private void initialListView() {
    lv_search = (ListView) findViewById(R.id.lv_search);
    list_memo = new ArrayList<Memo>();
    // 获取所有备忘
    Cursor cursor = MainActivity.myDB.getAll();

    while (cursor.moveToNext()) {
      Memo memo = new Memo(cursor.getString(0),
          cursor.getString(1),
          Boolean.valueOf(cursor.getString(2)),
          timestamp2str(cursor.getLong(3)));
      list_memo.add(memo);
    }

    ma_memo = new MemoListAdapter(SearchActivity.this, list_memo);
    lv_search.setAdapter(ma_memo);
    // 点击备忘跳转至备忘详情页
    lv_search.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(),
            ModifyItemActivity.class);
        intent.putExtra("type", "edit");
        Memo memo = (Memo) ma_memo.getItem(i);
        intent.putExtra("uuid", memo.getUUID());
        intent.putExtra("pos", i);
        startActivityForResult(intent, 0);
      }
    });
    // 长按删除备忘并且取消提醒
    lv_search.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
      @Override
      public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int i, long l) {
        final Memo memo = (Memo) ma_memo.getItem(i);
        Dialog alertDialog = new AlertDialog.Builder(getApplicationContext()).
            setTitle("删除事件").
            setMessage("确定删除事件: " + memo.getTopic() + "?").
            setNegativeButton("取消", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
              }
            }).
            setPositiveButton("确定", new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int which) {
                cancelReminder(memo.getUUID());

                Cursor cursor = myDB.getTask(memo.getUUID());
                cursor.moveToNext();

                long createTime = cursor.getLong(11);
                int code = (int) (createTime / 1000) - 1;

                cancelPlaceBroadcast(code);

                myDB.deleteTask(memo.getUUID(), "uuid");
                list_memo.remove(i);
                ma_memo.notifyDataSetChanged();
              }
            }).
            create();
        alertDialog.show();
        return true;
      }
    });
  }

  private void cancelReminder(String uuid) {
    Cursor cursor = myDB.getTask(uuid);
    cursor.moveToNext();

    String topic = cursor.getString(2);

    boolean isTimeRemind = Boolean.valueOf(cursor.getString(5));
    long thirty = cursor.getLong(6);
    long seventy = cursor.getLong(7);
    long ddl = cursor.getLong(3);
    AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);

    int ddl_code = (int) (ddl / 1000);
    int thirty_code = (int) (thirty / 1000);
    int seventy_code = (int) (seventy / 1000);

    Calendar calendar = Calendar.getInstance();

    PendingIntent ddl_operation = PendingIntent.getBroadcast(getApplicationContext(),
        ddl_code,
        new Intent(getApplicationContext(), AlarmReceiver.class).putExtra("id", ddl_code).putExtra("uuid", uuid).putExtra("process", 2).putExtra("topic", topic),
        PendingIntent.FLAG_UPDATE_CURRENT);
    PendingIntent thirty_operation = PendingIntent.getBroadcast(getApplicationContext(),
        thirty_code,
        new Intent(getApplicationContext(), AlarmReceiver.class).putExtra("id", thirty_code).putExtra("uuid", uuid).putExtra("process", 0).putExtra("topic", topic),
        PendingIntent.FLAG_UPDATE_CURRENT);
    PendingIntent seventy_operation = PendingIntent.getBroadcast(getApplicationContext(),
        seventy_code,
        new Intent(getApplicationContext(), AlarmReceiver.class).putExtra("id", seventy_code).putExtra("uuid", uuid).putExtra("process", 1).putExtra("topic", topic),
        PendingIntent.FLAG_UPDATE_CURRENT);
    calendar.setTimeZone(TimeZone.getTimeZone("GMT+8"));

    am.cancel(ddl_operation);

    if (isTimeRemind) {
      am.cancel(thirty_operation);
      am.cancel(seventy_operation);
    }

    // Toast.makeText(getApplicationContext(), "闹钟取消完毕~", Toast.LENGTH_SHORT).show();
  }

  private void cancelPlaceBroadcast(int id) {
    Intent intentService = new Intent(getApplicationContext(), LocationService.class);
    Intent intentBroadCast = new Intent(getApplicationContext(), LocationReceiver.class);

    intentService.setAction("ml.huangjw.memory.LOCATION_SERVICE");
    intentBroadCast.setAction("ml.huangjw.memory.ALARM_SERVICE");

    PendingIntent operation = PendingIntent
        .getBroadcast(getApplicationContext(), id, intentBroadCast, PendingIntent.FLAG_UPDATE_CURRENT);
    getApplicationContext().stopService(intentService);

    AlarmManager am = (AlarmManager) getApplicationContext().getSystemService(ALARM_SERVICE);
    am.cancel(operation);
  }

  String timestamp2str(long timestamp) {
    Date date = new Date(timestamp);
    return (new SimpleDateFormat("yyyy-MM-dd HH:mm").format(timestamp));
  }

  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    if (requestCode == 0 && resultCode == RESULT_OK) {
      int pos = data.getIntExtra("pos", 0);
      String topic = data.getStringExtra("topic");
      String ddl = data.getStringExtra("ddl");

      Memo memo = (Memo) ma_memo.getItem(pos);
      memo.setDDL(ddl);
      memo.setTopic(topic);

      ma_memo.notifyDataSetChanged();
    }
  }

  public class MemoListAdapter extends BaseAdapter implements Filterable {

    private List<Memo> memoList;
    private Context context;

    private MyFilter myFilter;
    private ArrayList<Memo> mOriginalValues;

    public MemoListAdapter(Context context, List<Memo> memoList) {
      this.memoList = memoList;
      this.context = context;
    }

    public List<Memo> getMemoList() {
      return memoList;
    }

    @Override
    public int getCount() {
      if (memoList == null) {
        return 0;
      }
      return memoList.size();
    }

    @Override
    public Object getItem(int position) {
      if (memoList == null) {
        return null;
      }
      return memoList.get(position);
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(final int position, View view, ViewGroup parent) {
      View convertView;

      convertView = LayoutInflater.from(context).inflate(R.layout.memo_item, null);

      final CheckBox cb_isFinished = (CheckBox) convertView.findViewById(R.id.cb_isFinished);
      final TextView tv_topic = (TextView) convertView.findViewById(R.id.tv_topic);
      TextView tv_ddl = (TextView) convertView.findViewById(R.id.tv_ddl);

      final String topic = memoList.get(position).getTopic();
      String ddl = memoList.get(position).getDDL();
      boolean isFinished = memoList.get(position).isFinished();

      tv_ddl.setText(ddl);
      cb_isFinished.setChecked(isFinished);
      tv_topic.setText(topic);

      cb_isFinished.setTag(0);

      cb_isFinished.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView,
                                     final boolean isChecked) {
          if ((int) cb_isFinished.getTag() == 1) {
            cb_isFinished.setTag(0);
            return;
          }

          String title = "";
          if (isChecked) {
            title = "是否完成\"" + topic + "\"";
          } else if (!isChecked) {
            title = "是否恢复\"" + topic + "\"";
          } else {
            return;
          }

          Dialog alertDialog = new AlertDialog.Builder(SearchActivity.this).
              setTitle(title).
              setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  cb_isFinished.setTag(1);
                  cb_isFinished.setChecked(!isChecked);
                }
              }).
              setPositiveButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  Memo memo = (Memo) getItem(position);

                  Cursor cursor = myDB.getTask(memo.getUUID());
                  cursor.moveToNext();

                  long createTime = cursor.getLong(11);
                  int code = (int) (createTime / 1000) - 1;

                  cancelPlaceBroadcast(code);
                  cancelReminder(memo.getUUID());
                  memo.setFinished(isChecked);
                  myDB.updateFinish(memo.getUUID(), isChecked);
                }
              }).
              create();
          alertDialog.show();
        }
      });

      return convertView;
    }

    @Override
    public Filter getFilter() {
      if (myFilter == null) {
        myFilter = new MyFilter();
      }
      return myFilter;
    }

    class MyFilter extends Filter {

      @Override
      protected FilterResults performFiltering(CharSequence prefix) {
        FilterResults results = new FilterResults();

        if (mOriginalValues == null) {
          synchronized (mLock) {
            // 将list的用户 集合转换给这个原始数据的ArrayList
            mOriginalValues = new ArrayList<Memo>(memoList);
          }
        }
        if (prefix == null || prefix.length() == 0) {
          synchronized (mLock) {
            ArrayList<Memo> list = new ArrayList<Memo>(mOriginalValues);
            results.values = list;
            results.count = list.size();
          }
        } else {
          // 做正式的筛选
          String prefixString = prefix.toString().toLowerCase();

          // 声明一个临时的集合对象 将原始数据赋给这个临时变量
          final ArrayList<Memo> values = mOriginalValues;

          final int count = values.size();

          // 新的集合对象
          final ArrayList<Memo> newValues = new ArrayList<Memo>(count);

          for (int i = 0; i < count; i++) {
            // 如果姓名的前缀相符或者电话相符就添加到新的集合
            final Memo value = (Memo) values.get(i);
            if (value.getTopic().toLowerCase().contains(prefixString) ||
                value.getDDL().replace(" ", "").contains(prefixString)) {
              newValues.add(value);
            }
          }
          // 然后将这个新的集合数据赋给FilterResults对象
          results.values = newValues;
          results.count = newValues.size();
        }

        return results;
      }

      @Override
      protected void publishResults(CharSequence constraint,
                                    FilterResults results) {
        // 重新将与适配器相关联的List重赋值一下
        memoList = (List<Memo>) results.values;

        if (results.count > 0) {
          notifyDataSetChanged();
        } else {
          notifyDataSetInvalidated();
        }
      }
    }
  }
}
