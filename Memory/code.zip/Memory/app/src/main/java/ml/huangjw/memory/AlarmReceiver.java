package ml.huangjw.memory;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Huangjw on 2016/12/16.
 */

// 接收广播, 发送时间提醒通知
public class AlarmReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context context, Intent intent) {
    String uuid = intent.getStringExtra("uuid"), topic = intent.getStringExtra("topic");
    int process = intent.getIntExtra("process", 2);
    int id = intent.getIntExtra("id", 0);
    String[] arr = new String[] {" 已经过了30%的时间", " 已经过了70%的时间", " 时间已经到了！！！"};
    NotificationManager manager =
      (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);

    Notification.Builder builder = new Notification.Builder(context);

    builder.setContentTitle("时间提醒")
    .setContentText(topic + arr[process])
    .setTicker("难忘提醒")
    .setAutoCancel(true)
    .setSmallIcon(R.mipmap.launcher)
    .setDefaults(Notification.DEFAULT_ALL);

    Intent mIntent = new Intent(context, MainActivity.class);
    mIntent.putExtra("uuid", uuid);
    PendingIntent mPendingIntent = PendingIntent.getActivity(context,
                                   id, mIntent, 0);
    builder.setContentIntent(mPendingIntent);

    Notification notify = builder.build();

    manager.notify(id, notify);
  }
}
